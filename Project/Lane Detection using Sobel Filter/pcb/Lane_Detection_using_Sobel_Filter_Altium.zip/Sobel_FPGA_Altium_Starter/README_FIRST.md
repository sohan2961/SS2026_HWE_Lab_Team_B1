# Sobel FPGA Altium Starter Project

This package is a **starter Altium Designer project** for a custom Artix-7 `XC7A100T-CSG324` board based on the uploaded requirements and Vivado schematic reference.

## Important limitation
This is **not manufacturing-ready**. A real Artix-7 BGA PCB needs careful power-tree design, bank voltage planning, length/impedance rules, BGA fanout, DRC/ERC, and signal-integrity checks. Use this package to start the Altium project, create the schematic structure, place major blocks, and prepare the pin/net plan.

## What is included

- `Sobel_FPGA_Altium_Starter.PrjPcb` — starter PCB project file.
- `Schematic_Generator.PrjScr` — Altium script project.
- `Scripts/Generate_Sobel_FPGA_Schematic.pas` — block-level schematic generator script.
- `Scripts/Generate_Sobel_FPGA_PCB_Placement.pas` — starter PCB placement/board-outline script.
- `Libraries/` — your uploaded FPGA symbol, footprint, integrated-library package, and STEP model.
- `Design_Data/BOM.csv` — starter bill of materials.
- `Design_Data/Nets_and_Connections.csv` — connection plan.
- `Design_Data/FPGA_Pin_Assignment_Template.csv` — pin assignment template; replace TBD pins with your final Vivado/XDC pin choices.
- `Outputs/Block_Diagram.svg` and `Outputs/PCB_Top_Placement.svg` — easy visual reference for schematic and board placement.

## Open in Altium Designer

1. Extract the ZIP.
2. Open `Sobel_FPGA_Altium_Starter.PrjPcb` in Altium Designer.
3. Add the library files from the `Libraries` folder to the project if Altium does not load them automatically.
4. Create a new schematic document and save it as `Docs/Sobel_FPGA_Block.SchDoc`.
5. Open `Schematic_Generator.PrjScr` and run `Generate_Sobel_FPGA_Schematic.pas`.
6. Create a new PCB document and save it as `Docs/Sobel_FPGA_PCB.PcbDoc`.
7. Run `Generate_Sobel_FPGA_PCB_Placement.pas`, then inspect placement manually.
8. Fill final FPGA ball pins in `FPGA_Pin_Assignment_Template.csv` and update the schematic before routing.

## Main design idea

The board has these main blocks:

- Artix-7 `XC7A100T-CSG324` FPGA
- 100 MHz clock oscillator
- SW0 slide switch input
- VGA DE-15 output with RGB, HSync, and VSync
- JTAG programming connector
- SPI/QSPI configuration flash
- 1.0 V, 1.8 V, and 3.3 V regulators
- Decoupling capacitors and optional debug LED

