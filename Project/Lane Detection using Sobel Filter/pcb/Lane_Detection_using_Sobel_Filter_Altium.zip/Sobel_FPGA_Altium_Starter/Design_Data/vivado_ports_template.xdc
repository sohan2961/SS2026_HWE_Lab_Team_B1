## Fill PACKAGE_PIN values after final FPGA pin planning.
## Do NOT use this directly until every TBD pin is replaced and bank voltages are checked.

#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { CLK100MHZ }]
#create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports { CLK100MHZ }]

#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { sw0 }]

#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaRed[0] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaRed[1] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaRed[2] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaRed[3] }]

#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaGreen[0] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaGreen[1] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaGreen[2] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaGreen[3] }]

#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaBlue[0] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaBlue[1] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaBlue[2] }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { vgaBlue[3] }]

#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { Hsync }]
#set_property -dict { PACKAGE_PIN TBD IOSTANDARD LVCMOS33 } [get_ports { Vsync }]
