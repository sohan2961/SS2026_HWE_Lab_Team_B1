# Stackup and routing guide for this starter board

Recommended starting point for an Artix-7 CSG324 BGA board: 6 layers or more.

Example 6-layer stackup:

1. Top signal / component placement
2. Solid GND plane
3. Power plane split: 1.0 V / 1.8 V / 3.3 V
4. Inner signal
5. Solid GND or power reference
6. Bottom signal

## Placement

- Put FPGA near board center.
- Put decoupling capacitors as close as possible to FPGA power balls, preferably on bottom side under/near the BGA.
- Put regulators near the FPGA but leave enough thermal copper.
- Put 100 MHz oscillator close to the FPGA clock input.
- Put VGA connector on the board edge.
- Put JTAG connector on another accessible edge.
- Put SPI flash near FPGA configuration pins.

## Routing rules

- Clock: short, clean, reference to solid GND, optional series resistor near oscillator.
- VGA: keep RGB and sync routes simple; no strict high-speed differential routing needed, but avoid noisy paths.
- Power: wide pours, many vias, low impedance path.
- BGA fanout: start with via-in-pad only if your PCB manufacturer supports it; otherwise check if dog-bone fanout works for your chosen design rules.
- Decoupling: use many short-via connections to power/GND planes.
