{******************************************************************************
  Generate_Sobel_FPGA_PCB_Placement.pas

  Altium Designer DelphiScript starter placement guide.

  Purpose:
    Provides the placement plan for a simple 160 mm x 100 mm starter board.
    Because native PcbDoc generation depends strongly on Altium version and
    installed libraries, this file keeps the plan explicit and safe.

  Placement coordinates are in mm, origin at bottom-left of board:
    Board outline: 160 x 100
    U1 FPGA:       X=80,  Y=52
    X1 clock:      X=45,  Y=58
    SW1 switch:    X=20,  Y=42
    J1 VGA:        X=145, Y=52, board edge
    J2 JTAG:       X=80,  Y=90
    U2 flash:      X=98,  Y=32
    U3/U4/U5 power:X=35,  Y=20
    Decoupling:    Around/under U1, shortest possible routes to power/GND

  Recommended manual workflow:
    1. Create Docs\Sobel_FPGA_PCB.PcbDoc.
    2. Draw a 160 mm x 100 mm board outline.
    3. Place U1 in the center.
    4. Place clock close to FPGA clock pin.
    5. Place VGA on right board edge.
    6. Place JTAG on top edge.
    7. Place flash close to FPGA config pins.
    8. Place regulators left/bottom with copper area for heat.
    9. Place decoupling capacitors as close as possible to FPGA power balls.
******************************************************************************}

Procedure Main;
Begin
    ShowMessage('PCB placement guide loaded. See Outputs\PCB_Top_Placement.svg and this script comments for exact starter placement. Create the PCB manually in Altium, then use Design_Data files for net planning.');
End;
