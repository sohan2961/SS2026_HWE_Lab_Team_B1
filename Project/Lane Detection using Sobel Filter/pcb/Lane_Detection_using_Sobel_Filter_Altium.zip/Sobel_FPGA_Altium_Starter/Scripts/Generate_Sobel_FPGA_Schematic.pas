{******************************************************************************
  Generate_Sobel_FPGA_Schematic.pas

  Altium Designer DelphiScript starter generator.

  Purpose:
    Creates a block-level schematic layout for the custom XC7A100T-CSG324
    Sobel/VGA board. This is intended to save setup time for a beginner.

  Important:
    This script creates the schematic structure only. You must still replace
    generic blocks with real components, assign the final FPGA ball pins, run
    ERC, and connect footprints before PCB routing.

  How to use:
    1. Open Altium Designer.
    2. Open Sobel_FPGA_Altium_Starter.PrjPcb.
    3. Create/open Docs\Sobel_FPGA_Block.SchDoc.
    4. Open Schematic_Generator.PrjScr.
    5. Run procedure Main from this script.

  If your Altium version gives an API object error, keep this file as the
  connection plan and use Design_Data\Nets_and_Connections.csv to draw the
  schematic manually.
******************************************************************************}

Procedure AddNote(X, Y : Integer; S : String);
Var
    Sheet : ISch_Document;
    Note  : ISch_TextFrame;
Begin
    Sheet := SchServer.GetCurrentSchDocument;
    If Sheet = Nil Then Exit;

    Note := SchServer.SchObjectFactory(eTextFrame, eCreate_GlobalCopy);
    If Note = Nil Then Exit;

    Note.Location := Point(MilsToCoord(X), MilsToCoord(Y));
    Note.Corner   := Point(MilsToCoord(X + 1600), MilsToCoord(Y + 500));
    Note.Text     := S;
    Sheet.RegisterSchObjectInContainer(Note);
End;

Procedure AddTitleBlock;
Begin
    AddNote(300, 7600,
        'Custom Artix-7 XC7A100T-CSG324 Sobel/VGA board - generated starter schematic');
    AddNote(300, 7100,
        'Replace generic blocks with real symbols/parts, then assign final FPGA ball pins and run ERC.');
End;

Procedure AddFPGA;
Begin
    AddNote(3700, 4300,
        'U1: XC7A100T-1CSG324C FPGA' + #13#10 +
        'Core HDL ports from Vivado:' + #13#10 +
        'CLK100MHZ, sw0, vgaRed[3:0], vgaGreen[3:0], vgaBlue[3:0], Hsync, Vsync');
End;

Procedure AddClock;
Begin
    AddNote(600, 5500,
        'X1: 100 MHz oscillator' + #13#10 +
        'Net: CLK100MHZ -> FPGA clock-capable pin' + #13#10 +
        'Power: 3.3 V, GND');
End;

Procedure AddSwitch;
Begin
    AddNote(600, 3900,
        'SW1: SW0 slide switch' + #13#10 +
        'Net: SW0 -> FPGA user I/O' + #13#10 +
        'Add pull-up/pull-down resistor');
End;

Procedure AddVGA;
Begin
    AddNote(7000, 4300,
        'J1: VGA DE-15 connector' + #13#10 +
        'Inputs from FPGA through resistor DAC:' + #13#10 +
        'R[3:0], G[3:0], B[3:0], Hsync, Vsync');
End;

Procedure AddJTAGFlash;
Begin
    AddNote(3700, 2100,
        'J2 + U2: JTAG / QSPI configuration' + #13#10 +
        'JTAG: TCK, TMS, TDI, TDO, VREF, GND' + #13#10 +
        'QSPI: CS_B, CCLK, DQ0..DQ3');
End;

Procedure AddPower;
Begin
    AddNote(3700, 6200,
        'Power tree' + #13#10 +
        'U3: 1.0 V VCCINT' + #13#10 +
        'U4: 1.8 V VCCAUX' + #13#10 +
        'U5: 3.3 V VCCO/config/VGA/clock' + #13#10 +
        'Add decoupling capacitors near FPGA pins');
End;

Procedure Main;
Var
    Sheet : ISch_Document;
Begin
    If SchServer = Nil Then
    Begin
        ShowMessage('Schematic server is not available. Open a schematic document first.');
        Exit;
    End;

    Sheet := SchServer.GetCurrentSchDocument;
    If Sheet = Nil Then
    Begin
        ShowMessage('Open or create Docs\Sobel_FPGA_Block.SchDoc first, then run this script.');
        Exit;
    End;

    SchServer.ProcessControl.PreProcess(Sheet, '');
    AddTitleBlock;
    AddClock;
    AddSwitch;
    AddFPGA;
    AddVGA;
    AddJTAGFlash;
    AddPower;
    SchServer.ProcessControl.PostProcess(Sheet, '');
    Sheet.GraphicallyInvalidate;
    ShowMessage('Starter block-level schematic notes placed. Now replace blocks with real symbols and wire nets from Design_Data\Nets_and_Connections.csv.');
End;
